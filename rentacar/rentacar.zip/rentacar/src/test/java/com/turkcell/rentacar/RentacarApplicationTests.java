package com.turkcell.rentacar;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentacarApplicationTests {

	@Test
	void contextLoads() {
	}

}
